import os
import sys
import zipfile
import shutil
import subprocess
import time

def main():
    try:
        # Le dossier parent du launcher (où le .exe est)
        parent_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        zip_path = os.path.join(parent_dir, "update.zip")  # le zip doit être placé ici par le launcher

        if not os.path.exists(zip_path):
            print("Fichier update.zip introuvable.")
            return

        # Extraction et remplacement des fichiers
        with zipfile.ZipFile(zip_path, 'r') as zip_ref:
            for member in zip_ref.namelist():
                target_path = os.path.join(parent_dir, member)
                # Supprimer si existe
                if os.path.exists(target_path):
                    if os.path.isdir(target_path):
                        shutil.rmtree(target_path)
                    else:
                        os.remove(target_path)
                zip_ref.extract(member, parent_dir)

        print("Mise à jour terminée !")

        # Supprimer le zip après extraction
        os.remove(zip_path)

        # Petit délai pour être sûr que tout est écrit
        time.sleep(1)

        # Relancer le launcher
        launcher_exe = os.path.join(parent_dir, "Launcher.exe")
        if os.path.exists(launcher_exe):
            subprocess.Popen([launcher_exe])
            print("Launcher relancé.")
        else:
            print("Launcher.exe introuvable !")

    except Exception as e:
        print(f"Erreur lors de la mise à jour : {e}")

if __name__ == "__main__":
    main()
